package com.example.regionalfruitdexfirebase;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class UploadActivity extends AppCompatActivity {
    private static final int CHOOSE_IMAGE_REQUEST = 1;
    private Button select_image;
    private EditText edit_image_name;
    private ImageView image_view;
    private Uri image_uri;
    private StorageReference storageReference;
    private DatabaseReference dbImageReference;
    private StorageTask uploadTask;
    private boolean imageWasUploaded;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);


        final EditText edit_fruitName = findViewById(R.id.fruit_name_input);
        final EditText edit_fruitLocalName = findViewById(R.id.fruit_local_name_input);
        final EditText edit_country = findViewById(R.id.fruit_country_input);
        final EditText edit_fruitInfo = findViewById(R.id.fruit_info_input);
        final EditText edit_fruit_attributes = findViewById(R.id.fruit_attributes_input);
        final EditText edit_fruit_taste = findViewById(R.id.fruit_taste_input);
        //final ImageButton add_fruitImage = findViewById(R.id.addFruitImage_btn);
        final Button add_fruit = findViewById(R.id.addFruit_btn);
        select_image = findViewById(R.id.button_select_image);
        edit_image_name = findViewById(R.id.set_image_name);
        image_view = findViewById(R.id.image_view);
        imageWasUploaded = false;

        storageReference = FirebaseStorage.getInstance().getReference("uploads");
        dbImageReference = FirebaseDatabase.getInstance().getReference("uploads");

        select_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImageFileChooser();
            }
        });

        DAOFruit dao = new DAOFruit();

        add_fruit.setOnClickListener(v -> {
            name = edit_fruitName.getText().toString();

            Fruit frt = new Fruit(edit_fruitName.getText().toString(),
                    edit_fruitLocalName.getText().toString(),
                    edit_country.getText().toString(),
                    edit_fruitInfo.getText().toString(),
                    edit_fruit_attributes.getText().toString(),
                    edit_fruit_taste.getText().toString());

                upload();
                if(imageWasUploaded){
                    dao.add(frt).addOnSuccessListener(suc -> {

                        Toast.makeText(this, "New fruit added", Toast.LENGTH_SHORT).show();

                    }).addOnFailureListener(er -> {

                        Toast.makeText(this, "" + er.getMessage(), Toast.LENGTH_SHORT).show();

                    });

                }




        });

    }
    private void openImageFileChooser(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,CHOOSE_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == CHOOSE_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null){
            image_uri  = data.getData();
            //Picasso.with(this).load(image_uri).into(image_view);
            Picasso.get().load(image_uri).into(image_view);
        }
    }

    private String getImageExtension(Uri uri){//Gets extension of image
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    /*private void uploadImage(){
        if (image_uri != null){
            StorageReference imageReference = storageReference.child(System.currentTimeMillis() + "." + getImageExtension(image_uri));
            uploadTask = imageReference.putFile(image_uri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            //ImageUpload uploadedImage = new ImageUpload(edit_image_name.getText().toString(),
                                    //imageReference.getDownloadUrl().toString());

                            //String uploadId = dbImageReference.push().getKey();
                            //dbImageReference.child(uploadId).setValue(uploadedImage);

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(UploadActivity.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                }
            });


        }
        else{
            Toast.makeText(this,"No image selected.",Toast.LENGTH_SHORT).show();
        }
    }*/
    private void upload(){
        if (image_uri != null){
            StorageReference imageReference = storageReference.child(name + "." + getImageExtension(image_uri));
            uploadTask = imageReference.putFile(image_uri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            //ImageUpload uploadedImage = new ImageUpload(edit_image_name.getText().toString(),
                            //imageReference.getDownloadUrl().toString());

                            //String uploadId = dbImageReference.push().getKey();
                            //dbImageReference.child(uploadId).setValue(uploadedImage);


                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(UploadActivity.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    });
            imageWasUploaded = true;
        }
        else{
            Toast.makeText(this,"No image selected.",Toast.LENGTH_SHORT).show();
            imageWasUploaded = false;
        }

    }
}