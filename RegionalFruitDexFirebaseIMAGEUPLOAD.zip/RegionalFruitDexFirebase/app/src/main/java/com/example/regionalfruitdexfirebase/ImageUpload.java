package com.example.regionalfruitdexfirebase;

public class ImageUpload {
    private String name;
    private String imageUrl;

    public ImageUpload(){}//Required Empty Constructor

    public ImageUpload(String imageName, String url){
        name = imageName;
        imageUrl = url;
    }

    public String getName(){
        return name;
    }
    public String getUrl(){
        return imageUrl;
    }

    public void setName(String imageName){
        name = imageName;
    }
    public void setUrl(String url){
        imageUrl = url;
    }

}
