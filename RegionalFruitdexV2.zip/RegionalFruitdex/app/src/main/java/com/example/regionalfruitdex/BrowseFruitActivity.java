package com.example.regionalfruitdex;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ListView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class BrowseFruitActivity extends Activity {

    int i=0;
    private TextView textView;
    boolean isTrinidad = false;
    final static public String TRINIDAD_TAG = "Trinidad";

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_fruit);

        if(savedInstanceState != null){
            i = (int)savedInstanceState.get("i");
        }
        else{
            int i =0;
        }
        textView = findViewById(R.id.textView);
        if(getIntent().hasExtra(HomepageActivity.s)){
            i =  getIntent().getIntExtra(HomepageActivity.s,i);
            textView.setText("Select a Country to see all the fruits that grow there.");
        }

        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> listView, View itemView, int pos, long id){
                if((pos >= 0)&&(pos<=2)){
                    if(pos == 0){
                        isTrinidad = true;
                        Intent intent = new Intent(BrowseFruitActivity.this,BrowseCountriesActivity.class);
                        intent.putExtra(TRINIDAD_TAG,isTrinidad);
                        startActivity(intent);
                    }
                    else{
                        Intent intent = new Intent(BrowseFruitActivity.this,BrowseCountriesActivity.class);
                        intent.putExtra(TRINIDAD_TAG,isTrinidad);
                        startActivity(intent);
                    }

                }
            }
        };
        ListView listView = (ListView) findViewById(R.id.list_countries);
        listView.setOnItemClickListener(itemClickListener);

}

    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        int temp = i;
        savedInstanceState.putInt("s", temp);
    }
}