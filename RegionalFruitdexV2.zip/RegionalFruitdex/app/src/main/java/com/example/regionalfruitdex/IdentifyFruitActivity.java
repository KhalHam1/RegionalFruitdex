package com.example.regionalfruitdex;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class IdentifyFruitActivity extends AppCompatActivity {

    int i;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_identify_fruit);

        if(savedInstanceState != null){
            i = (int)savedInstanceState.get("i");
        }

        else{
            int i =0;

        }
        textView = findViewById(R.id.textView);

        if(getIntent().hasExtra(HomepageActivity.s)){
            i =  getIntent().getIntExtra(HomepageActivity.s,i);

            textView.setText("Numero "+i+"\nFRUITS WILL BE IDENTIFIED HERE!");



        }
    }

    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        int temp = i;
        savedInstanceState.putInt("s", temp);
    }
}