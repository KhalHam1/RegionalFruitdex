package com.example.regionalfruitdex;


import android.app.Activity;
import android.widget.TextView;
import android.widget.ImageView;
import android.os.Bundle;

public class FruitDisplayActivity extends Activity {

    public static final String EXTRA_FRUITID = "fruitId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fruit_display);

        //Get the fruit from the intent
        int fruitId = (Integer)getIntent().getExtras().get(EXTRA_FRUITID);
        Fruit fruit = Fruit.FRUIT_TRINIDAD[fruitId];

        //Populate the fruit name
        TextView fruitName = (TextView) findViewById(R.id.fruitName);
        fruitName.setText(fruit.getFruitName());

        //Populate the fruit description
        TextView fruitDescription = (TextView) findViewById(R.id.fruitDescription);
        fruitDescription.setText(fruit.getFruitDescription());

        //Populate the image for the fruit
        ImageView image = (ImageView) findViewById(R.id.fruitImage);
        image.setImageResource(fruit.getImageId());
        image.setContentDescription(fruit.getFruitName());
    }
}