package com.example.regionalfruitdex;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.content.Intent;

public class BrowseCountriesActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_countries);
        //if(getIntent().hasExtra(ProductOrderingActivity.Products_TAG)){}
        if(getIntent().hasExtra(BrowseFruitActivity.TRINIDAD_TAG)){

        }

        ArrayAdapter<Fruit> fruitListAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,Fruit.FRUIT_TRINIDAD);

        ListView listFruits = (ListView) findViewById(R.id.list_fruits);
        listFruits.setAdapter(fruitListAdapter);

        AdapterView.OnItemClickListener itemClickListener2 = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> listFruits, View fruitView, int pos, long id) {
                Intent intent = new Intent(BrowseCountriesActivity.this,FruitDisplayActivity.class);
                intent.putExtra(FruitDisplayActivity.EXTRA_FRUITID, (int) id);
                startActivity(intent);
            }
        };
        listFruits.setOnItemClickListener(itemClickListener2);
    }
}