package com.example.regionalfruitdexfirebase;

public class Fruit {
    private String name;
    private String localName;
    private String country;
    private String information;
    private String attributes;
    private String taste;
    private String colorPalette;
    private String regionFound;
    public Fruit(){}

    public Fruit(String name, String localName, String country, String information, String attributes, String taste){
        this.name = name;
        this.localName = localName;
        this.country = country;
        this.information = information;
        this.attributes = attributes;
        this.taste = taste;
        colorPalette = "n/a";
        regionFound = "";

    }

    public String getName() { return name; }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocalName() {
        return localName;
    }

    public void setLocalName(String localName) {
        this.localName = localName;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getInformation() {
        return information;
    }

    public void setInformation(String information) {
        this.information = information;
    }

    public String getAttributes() {
        return attributes;
    }

    public void setAttributes(String attributes) {
        this.attributes = attributes;
    }

    public String getTaste() {
        return taste;
    }

    public void setTaste(String taste) {
        this.taste = taste;
    }

    public String getColorPalette(){
        return colorPalette;
    }
    public void setColorPalette(String colorPalette) {
        this.colorPalette = colorPalette;
    }

    public String getRegionFound(){
        return regionFound;
    }
    public void setRegionFound(String regionFound) {
        this.regionFound = regionFound;
    }


}
