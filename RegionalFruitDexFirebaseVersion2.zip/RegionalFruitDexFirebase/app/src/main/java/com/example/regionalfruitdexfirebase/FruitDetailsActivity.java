package com.example.regionalfruitdexfirebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FruitDetailsActivity extends AppCompatActivity {

    public static final String EXTRA_FRUITID = "fruitId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fruit_details);

        String fruitName = (String) getIntent().getExtras().get(EXTRA_FRUITID);
        ArrayList<Fruit> fruits = new ArrayList<>();
        System.out.println(fruitName);

        //Gets a reference to the Fruit Branch
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Fruit");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                fruits.clear();
                for (DataSnapshot snapShot : snapshot.getChildren()) {

                    Fruit fruit = snapShot.getValue(Fruit.class);
                    fruits.add(fruit);

                }
                int i = 0;
                TextView fruitNameText = (TextView) findViewById(R.id.fruitName);
                TextView fruitCountryText = (TextView) findViewById(R.id.fruitCountry);
                TextView fruitLocalNameText = (TextView) findViewById(R.id.fruitLocal);
                TextView fruitInformationText = (TextView) findViewById(R.id.fruitInformation);
                TextView fruitAttributesText = (TextView) findViewById(R.id.fruitAttributes);
                TextView fruitTasteText = (TextView) findViewById(R.id.fruitTaste);
                while (i < fruits.size()){
                    if(fruitName.equals(fruits.get(i).getName())){
                        fruitNameText.setText("Name: "+fruitName+"\n");
                        fruitCountryText.setText("Country: "+fruits.get(i).getCountry()+"\n");
                        fruitLocalNameText.setText("Local Name: "+fruits.get(i).getLocalName()+"\n");
                        fruitInformationText.setText("Information: "+fruits.get(i).getInformation()+"\n\n");
                        fruitAttributesText.setText("Attributes: "+fruits.get(i).getAttributes()+"\n\n");
                        fruitTasteText.setText("Taste: "+fruits.get(i).getTaste());

                    }
                    i++;
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}