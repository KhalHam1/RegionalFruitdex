package com.example.regionalfruitdexfirebase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    int i = 10;
    final static public String s = "Numero: ";
    final static public String EXTRA_VAL = "Value";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        System.out.println("On Create");

        if(savedInstanceState != null){
            i = (int)savedInstanceState.get("i");
        }
        else{

            i = 10;
        }
    }

    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        int tempInt = new Integer(i);
        savedInstanceState.putInt("i",tempInt);
    }

    public void onClickBrowseFruit(View view){
        Intent intent = new Intent(MainActivity.this, BrowseActivity.class);
        intent.putExtra(s, i);
        startActivity(intent);


    }

    public void onClickIdentifyFruit(View view){
        Intent intent = new Intent(MainActivity.this, IdentificationActivity.class);
        intent.putExtra(s, i);
        startActivity(intent);


    }

    public void onClickUploadEntry(View view){
        Intent intent = new Intent(MainActivity.this, UploadActivity.class);
        intent.putExtra(s, i);
        startActivity(intent);


    }

}