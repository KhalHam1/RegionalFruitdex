package com.example.regionalfruitdexfirebase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class UploadActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);


        final EditText edit_fruitName = findViewById(R.id.fruit_name_input);
        final EditText edit_fruitLocalName = findViewById(R.id.fruit_local_name_input);
        final EditText edit_country = findViewById(R.id.fruit_country_input);
        final EditText edit_fruitInfo = findViewById(R.id.fruit_info_input);
        final EditText edit_fruit_attributes = findViewById(R.id.fruit_attributes_input);
        final EditText edit_fruit_taste = findViewById(R.id.fruit_taste_input);
        //final ImageButton add_fruitImage = findViewById(R.id.addFruitImage_btn);
        final Button add_fruit = findViewById(R.id.addFruit_btn);

        DAOFruit dao = new DAOFruit();
        add_fruit.setOnClickListener(v -> {
            Fruit frt = new Fruit(edit_fruitName.getText().toString(),
                    edit_fruitLocalName.getText().toString(),
                    edit_country.getText().toString(),
                    edit_fruitInfo.getText().toString(),
                    edit_fruit_attributes.getText().toString(),
                    edit_fruit_taste.getText().toString());

            dao.add(frt).addOnSuccessListener(suc -> {

                Toast.makeText(this, "New fruit added", Toast.LENGTH_SHORT).show();

            }).addOnFailureListener(er -> {

                Toast.makeText(this, "" + er.getMessage(), Toast.LENGTH_SHORT).show();

            });
        });

    }

}