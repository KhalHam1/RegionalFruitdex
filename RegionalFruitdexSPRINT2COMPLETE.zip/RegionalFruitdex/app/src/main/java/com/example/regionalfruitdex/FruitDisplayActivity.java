package com.example.regionalfruitdex;


import android.app.Activity;
import android.widget.TextView;
import android.widget.ImageView;
import android.os.Bundle;
import android.widget.Toast;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;


public class FruitDisplayActivity extends AppCompatActivity {

    public static final String EXTRA_FRUITID = "fruitId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fruit_display);

        //Get the fruit from the intent
        int fruitId = (Integer)getIntent().getExtras().get(EXTRA_FRUITID);
        //Fruit fruit = Fruit.FRUIT_TRINIDAD[fruitId];
        SQLiteOpenHelper fruitDatabaseHelper = new FruitDatabaseHelper(this);

        try{
            SQLiteDatabase db = fruitDatabaseHelper.getReadableDatabase();
            Cursor cursor = db.query ("FRUIT",
                    new String[] {"NAME", "COUNTRY", "LOCAL_NAME", "DESCRIPTION", "IMAGE_ID"},
                    "_id = ?",
                    new String[] {Integer.toString(fruitId)},
                    null, null, null);

            if(cursor.moveToFirst()){
                String fruitName = cursor.getString(0);
                String fruitCountry = cursor.getString(1);
                String fruitLocalName = cursor.getString(2);
                String fruitDescription = cursor.getString(3);
                int imageId = cursor.getInt(4);

                TextView fruitNameText = (TextView) findViewById(R.id.fruitName);
                fruitNameText.setText("Name: "+fruitName);

                TextView fruitCountryText = (TextView) findViewById(R.id.fruitCountry);
                fruitCountryText.setText("Country: ");
                fruitCountryText.append(fruitCountry);

                TextView fruitLocalNameText = (TextView) findViewById(R.id.fruitLocal);
                fruitLocalNameText.setText("Local Name: "+ fruitLocalName);
                //fruitCountryText.append(fruitLocalName);

                TextView fruitDescriptionText = (TextView) findViewById(R.id.fruitDescription);
                fruitDescriptionText.setText("\nAbout "+fruitName+":\n");
                fruitDescriptionText.append(fruitDescription);

                ImageView photo = (ImageView)findViewById(R.id.fruitImage);
                photo.setImageResource(imageId);
                photo.setContentDescription(fruitName);

            }

        } catch(SQLiteException e) {
            Toast toast = Toast.makeText(this, "Database unavailable", Toast.LENGTH_SHORT);
            toast.show();}

        /*//Populate the fruit name
        TextView fruitName = (TextView) findViewById(R.id.fruitName);
        fruitName.setText(fruit.getFruitName());

        //Populate the fruit description
        TextView fruitDescription = (TextView) findViewById(R.id.fruitDescription);
        fruitDescription.setText(fruit.getFruitDescription());

        //Populate the image for the fruit
        ImageView image = (ImageView) findViewById(R.id.fruitImage);
        image.setImageResource(fruit.getImageId());
        image.setContentDescription(fruit.getFruitName());*/
    }
}