package com.example.regionalfruitdex;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;


public class UploadEntryActivity extends AppCompatActivity {

    int i;
    private SQLiteDatabase db;
    private Cursor cursor;
    SQLiteOpenHelper fruitDatabaseHelper = new FruitDatabaseHelper(this);
    private EditText inputName;
    private EditText inputLocalName;
    private EditText inputCountry;
    private EditText inputDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_entry);



        //if(savedInstanceState != null){
            //i = (int)savedInstanceState.get("i");
        //}

        //else{
            //int i =0;
        //}
        //textView = findViewById(R.id.textView);

        //if(getIntent().hasExtra(HomepageActivity.s)){
            //i =  getIntent().getIntExtra(HomepageActivity.s,i);
            //textView.setText("Numero "+i+"\nENTRIES WILL BE UPLOADED HERE!");
        //}
    }

    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        //int temp = i;
        //savedInstanceState.putInt("s", temp);
    }

    public void onButtonClick(View view){

        db = fruitDatabaseHelper.getWritableDatabase();
        inputName = (EditText) findViewById(R.id.fruit_name_input);
        inputLocalName = (EditText) findViewById(R.id.fruit_local_name_input);
        inputCountry = (EditText) findViewById(R.id.fruit_country);
        inputDescription = (EditText) findViewById(R.id.fruit_info_input);

        String name = inputName.getText().toString();
        String localName = inputLocalName.getText().toString();
        String country = inputCountry.getText().toString();
        String description = inputDescription.getText().toString();
        if(localName.equals("")){
            localName = "No local name.";
        }
        if(name.isEmpty()){
            Toast.makeText(this, "No name entered.", Toast.LENGTH_SHORT).show();
        }
        else{
            if(description.isEmpty()){
                Toast.makeText(this, "Please add a description.", Toast.LENGTH_SHORT).show();
            }
            else{
                if((country.equals("Trinidad and Tobago")) || (country.equals("Barbados")) || (country.equals("Grenada"))){
                    ContentValues newEntry = new ContentValues();
                    newEntry.put("NAME",name);
                    newEntry.put("COUNTRY",country);
                    newEntry.put("LOCAL_NAME",localName);
                    newEntry.put("DESCRIPTION", description);
                    newEntry.put("IMAGE_ID", R.drawable.custom);

                    cursor = db.query("FRUIT",new String[]{"NAME", "COUNTRY"}, null,null,null,null,null);
                    cursor.moveToFirst();
                    do{
                        String nameTemp = cursor.getString(0);
                        String countryTemp = cursor.getString(1);
                        if(nameTemp.equals(name)&&countryTemp.equals(country)){
                            Toast.makeText(this, "Fruit Already Exists for Selected Country", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }while(cursor.moveToNext());

                    db.insert("FRUIT",null,newEntry);
                    Toast.makeText(this, "Fruit Added!", Toast.LENGTH_SHORT).show();
                    db.close();

                    Intent intent = new Intent(UploadEntryActivity.this, HomepageActivity.class);
                    intent.putExtra(HomepageActivity.EXTRA_VAL, (int)i);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(this, "Country Name Invalid or Currently Not Supported.", Toast.LENGTH_SHORT).show();
                }
            }
        }



    }
}