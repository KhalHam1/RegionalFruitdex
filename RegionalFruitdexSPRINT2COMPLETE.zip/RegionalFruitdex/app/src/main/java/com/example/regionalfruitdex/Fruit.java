package com.example.regionalfruitdex;

public class Fruit {
    private String fruitName;
    private String fruitDescription;
    private int imageId;

    public static final Fruit[] FRUIT_TRINIDAD =
            {new Fruit("Banana", "Banana Info", R.drawable.bananas),
             new Fruit("Julie Mango", "Julie Mango Info", R.drawable.juliemango),
             new Fruit("Pomerac", "Pomerac Info", R.drawable.pomerac)};

    private Fruit(String fruitName, String fruitDescription, int imageId){
        this.fruitName = fruitName;
        this.fruitDescription = fruitDescription;
        this.imageId = imageId;
    }
    public String getFruitName() {
        return fruitName;
    }
    public String getFruitDescription() {
        return fruitDescription;
    }
    public int getImageId() {
        return imageId;
    }
    public String toString() {
        return this.fruitName;
    }
}
