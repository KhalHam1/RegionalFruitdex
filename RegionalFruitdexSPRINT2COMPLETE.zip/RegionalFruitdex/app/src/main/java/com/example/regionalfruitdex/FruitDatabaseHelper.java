package com.example.regionalfruitdex;


import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

public class FruitDatabaseHelper extends SQLiteOpenHelper {

    private static String DB_NAME = "FruitLibrary";
    private static int DB_VERSION = 1;

    public FruitDatabaseHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        updateDatabase(db,0,DB_VERSION);
        insertFruit(db,"Banana","Trinidad and Tobago", "Fig","This is the description for Bananas.",R.drawable.bananas);
        insertFruit(db,"Julie Mango","Barbados", "Julie Mango","This is the description for Julie Mangoes.",R.drawable.juliemango);
        insertFruit(db,"Pomerac","Grenada", "Pomerac","This is the description for Pomerac.",R.drawable.pomerac);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        updateDatabase(db,oldVersion,newVersion);
    }

    private void updateDatabase(SQLiteDatabase db, int oldVersion, int newVersion){
        if(oldVersion < 1){
            db.execSQL("CREATE TABLE FRUIT(_id INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, COUNTRY TEXT, " +
                    "LOCAL_NAME TEXT, DESCRIPTION TEXT, IMAGE_ID INTEGER)");
            //insertFruit(db,"Banana","Trinidad and Tobago", "Fig","This is the description for Bananas.",R.drawable.bananas);
            //insertFruit(db,"Julie Mango","Barbados", "Julie Mango","This is the description for Julie Mangoes.",R.drawable.juliemango);
            //insertFruit(db,"Pomerac","Grenada", "Pomerac","This is the description for Pomerac.",R.drawable.pomerac);
        }

        if (oldVersion < 2) {

        }
    }

    private void insertFruit(SQLiteDatabase db, String name,String country, String localName, String description, int imageId){
        ContentValues row = new ContentValues();
        row.put("NAME",name);
        row.put("COUNTRY",country);
        row.put("LOCAL_NAME", localName);
        row.put("DESCRIPTION", description);
        row.put("IMAGE_ID", imageId);
        db.insert("FRUIT",null,row);
    }
}
