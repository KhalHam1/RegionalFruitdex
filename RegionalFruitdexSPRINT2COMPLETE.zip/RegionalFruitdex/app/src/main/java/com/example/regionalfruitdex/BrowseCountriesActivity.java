package com.example.regionalfruitdex;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.content.Intent;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class BrowseCountriesActivity extends AppCompatActivity {

    private SQLiteDatabase db;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_countries);
        ListView listFruits = (ListView) findViewById(R.id.list_fruits);
        SQLiteOpenHelper fruitDatabaseHelper = new FruitDatabaseHelper(this);

        if(getIntent().hasExtra(BrowseFruitActivity.TRINIDAD_TAG)){
            try{
                db = fruitDatabaseHelper.getReadableDatabase();
                cursor = db.query("FRUIT",new String[]{"_id", "NAME"}, "COUNTRY = ?",new String[] {"Trinidad and Tobago"},null,null,null);
                SimpleCursorAdapter listAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_1,cursor,new String[]{"NAME"}, new int[]{android.R.id.text1},0);
                listFruits.setAdapter(listAdapter);
            }catch(SQLiteException e){
                Toast toast = Toast.makeText(this, "Database unavailable", Toast.LENGTH_SHORT);
                toast.show();
            }
            //Create a listener to listen for clicks in the list view
            AdapterView.OnItemClickListener itemClickListener =
                    new AdapterView.OnItemClickListener(){
                        public void onItemClick(AdapterView<?> listDrinks,
                                                View itemView,
                                                int position,
                                                long id) {
                            //Pass the drink the user clicks on to DrinkActivity
                            Intent intent = new Intent(BrowseCountriesActivity.this,
                                    FruitDisplayActivity.class);
                            intent.putExtra(FruitDisplayActivity.EXTRA_FRUITID, (int) id);
                            startActivity(intent);
                        }
                    };
            listFruits.setOnItemClickListener(itemClickListener);
        }

        if(getIntent().hasExtra(BrowseFruitActivity.BARBADOS_TAG)){
            try{
                db = fruitDatabaseHelper.getReadableDatabase();
                cursor = db.query("FRUIT",new String[]{"_id", "NAME"}, "COUNTRY = ?",new String[] {"Barbados"},null,null,null);
                SimpleCursorAdapter listAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_1,cursor,new String[]{"NAME"}, new int[]{android.R.id.text1},0);
                listFruits.setAdapter(listAdapter);
            }catch(SQLiteException e){
                Toast toast = Toast.makeText(this, "Database unavailable", Toast.LENGTH_SHORT);
                toast.show();
            }
            //Create a listener to listen for clicks in the list view
            AdapterView.OnItemClickListener itemClickListener =
                    new AdapterView.OnItemClickListener(){
                        public void onItemClick(AdapterView<?> listDrinks,
                                                View itemView,
                                                int position,
                                                long id) {
                            //Pass the drink the user clicks on to DrinkActivity
                            Intent intent = new Intent(BrowseCountriesActivity.this,
                                    FruitDisplayActivity.class);
                            intent.putExtra(FruitDisplayActivity.EXTRA_FRUITID, (int) id);
                            startActivity(intent);
                        }
                    };
            listFruits.setOnItemClickListener(itemClickListener);
        }

        if(getIntent().hasExtra(BrowseFruitActivity.GRENADA_TAG)){
            try{
                db = fruitDatabaseHelper.getReadableDatabase();
                cursor = db.query("FRUIT",new String[]{"_id", "NAME"}, "COUNTRY = ?",new String[] {"Grenada"},null,null,null);
                SimpleCursorAdapter listAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_1,cursor,new String[]{"NAME"}, new int[]{android.R.id.text1},0);
                listFruits.setAdapter(listAdapter);
            }catch(SQLiteException e){
                Toast toast = Toast.makeText(this, "Database unavailable", Toast.LENGTH_SHORT);
                toast.show();
            }
            //Create a listener to listen for clicks in the list view
            AdapterView.OnItemClickListener itemClickListener =
                    new AdapterView.OnItemClickListener(){
                        public void onItemClick(AdapterView<?> listDrinks,
                                                View itemView,
                                                int position,
                                                long id) {
                            //Pass the drink the user clicks on to DrinkActivity
                            Intent intent = new Intent(BrowseCountriesActivity.this,
                                    FruitDisplayActivity.class);
                            intent.putExtra(FruitDisplayActivity.EXTRA_FRUITID, (int) id);
                            startActivity(intent);
                        }
                    };
            listFruits.setOnItemClickListener(itemClickListener);
        }


        //Assign the listener to the list view
        //listDrinks.setOnItemClickListener(itemClickListener);
        //if(getIntent().hasExtra(BrowseFruitActivity.TRINIDAD_TAG)){

            /*try {
                db = fruitDatabaseHelper.getReadableDatabase();
                cursor = db.query("FRUIT",
                        new String[] {"_id", "NAME"},
                        null, null, null, null, null);
                SimpleCursorAdapter listAdapter = new SimpleCursorAdapter(this,
                        android.R.layout.simple_list_item_1,
                        cursor,
                        new String[] {"NAME"},
                        new int[] {android.R.id.text1},
                        0);
                listFruits.setAdapter(listAdapter);
                //cursor.close();
                //db.close();

            } catch (SQLiteException e) {
                String s = e.getMessage();
                Toast toast = Toast.makeText(this, "Database unavailable: "+s, Toast.LENGTH_LONG);
                toast.show();
            }*/

            /*ArrayAdapter<Fruit> fruitListAdapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_list_item_1,Fruit.FRUIT_TRINIDAD);

            ListView listFruits = (ListView) findViewById(R.id.list_fruits);
            listFruits.setAdapter(fruitListAdapter);

            AdapterView.OnItemClickListener itemClickListener2 = new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> listFruits, View fruitView, int pos, long id) {
                    Intent intent = new Intent(BrowseCountriesActivity.this,FruitDisplayActivity.class);
                    intent.putExtra(FruitDisplayActivity.EXTRA_FRUITID, (int) id);
                    startActivity(intent);
                }
            };
            listFruits.setOnItemClickListener(itemClickListener2);
        }*/

       /* ArrayAdapter<Fruit> fruitListAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,Fruit.FRUIT_TRINIDAD);

        ListView listFruits = (ListView) findViewById(R.id.list_fruits);
        listFruits.setAdapter(fruitListAdapter);

        AdapterView.OnItemClickListener itemClickListener2 = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> listFruits, View fruitView, int pos, long id) {
                Intent intent = new Intent(BrowseCountriesActivity.this,FruitDisplayActivity.class);
                intent.putExtra(FruitDisplayActivity.EXTRA_FRUITID, (int) id);
                startActivity(intent);
            }
        };
        listFruits.setOnItemClickListener(itemClickListener2);*/
    }
    @Override
    public void onDestroy(){
        super.onDestroy();
        cursor.close();
        db.close();
    }
}