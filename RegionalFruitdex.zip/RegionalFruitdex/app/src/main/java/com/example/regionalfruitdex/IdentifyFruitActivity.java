package com.example.regionalfruitdex;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class IdentifyFruitActivity extends AppCompatActivity {

    int i;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_identify_fruit);
        //System.out.println("COA onCreate");

        if(savedInstanceState != null){
            //orderList = (ArrayList<Orders>) savedInstanceState.get("orderList");
            i = (int)savedInstanceState.get("i");
            //completeOrder = (TextView) savedInstanceState.get("completeOrder");
            //completeOrderHeading = (TextView) savedInstanceState.get("completeOrderHeading");
            //i = (int) savedInstanceState.get("i");
        }

        else{
            int i =0;
            //orderList = new ArrayList<>();
            //orderList.add(0,null);

            //productList = new ArrayList<>();
            //productList.add(0,null);

        }
        textView = findViewById(R.id.textView);

        if(getIntent().hasExtra(HomepageActivity.s)){
            i =  getIntent().getIntExtra(HomepageActivity.s,i);

            textView.setText("Numero "+i+"\nFRUITS WILL BE IDENTIFIED HERE!");



        }
    }

    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        int temp = i;
        //ArrayList<Orders> temp = new ArrayList<Orders>(orderList);
        //ArrayList<Product> temp2 = new ArrayList<Product>(productList);
        savedInstanceState.putInt("s", temp);
        //savedInstanceState.putSerializable("productList", temp2);
    }
}