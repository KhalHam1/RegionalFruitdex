package com.example.regionalfruitdex;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class BrowseFruitActivity extends AppCompatActivity {

    int i=0;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_fruit);
        //System.out.println("COA onCreate");

        if(savedInstanceState != null){
            //orderList = (ArrayList<Orders>) savedInstanceState.get("orderList");
            i = (int)savedInstanceState.get("i");
            //completeOrder = (TextView) savedInstanceState.get("completeOrder");
            //completeOrderHeading = (TextView) savedInstanceState.get("completeOrderHeading");
            //i = (int) savedInstanceState.get("i");
        }

        else{
            int i =0;
            //orderList = new ArrayList<>();
            //orderList.add(0,null);

            //productList = new ArrayList<>();
            //productList.add(0,null);

        }
        textView = findViewById(R.id.textView);

        if(getIntent().hasExtra(HomepageActivity.s)){
            i =  getIntent().getIntExtra(HomepageActivity.s,i);

            textView.setText("Numero "+i+"\nFRUITS WILL BE BROWSED HERE!");



    }
}

    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        int temp = i;
        //ArrayList<Orders> temp = new ArrayList<Orders>(orderList);
        //ArrayList<Product> temp2 = new ArrayList<Product>(productList);
        savedInstanceState.putInt("s", temp);
        //savedInstanceState.putSerializable("productList", temp2);
    }
}